import os
import sys
import csv
import datetime
import hashlib
from datetime import datetime as _dt

from PyQt6.QtCore import Qt, QSize, QDate
from PyQt6.QtGui import (
    QColor, QFont, QIcon, QLinearGradient, QBrush, QPainter, QPen,
)
from PyQt6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QDateEdit, QDialog, QDialogButtonBox,
    QFormLayout, QFrame, QGraphicsDropShadowEffect, QGridLayout,
    QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem,
    QMainWindow, QMessageBox, QPushButton, QScrollArea,
    QStackedWidget, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from backend.config import *
from backend.utils import *
from backend.database import *
from backend.auth import *
from backend.inventory import *
from backend.queue_logic import *
from backend.dashboard_stats import DashboardStats as _Stats
from ui.pages.base_page import BasePage
from ui.pages.table_page import TablePage

# =============================================================================

# ── Icon circle widget ────────────────────────────────────────────────────────

class _IconCircle(QWidget):
    """Rounded square with an emoji icon, coloured background."""
    def __init__(self, emoji: str, bg: str, size: int = 40):
        super().__init__()
        self.setFixedSize(size, size)
        self._emoji = emoji
        self._bg    = QColor(bg)
        self._size  = size

    def paintEvent(self, _event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(self._bg))
        r = self._size * 0.25
        p.drawRoundedRect(0, 0, self._size, self._size, r, r)
        p.setPen(QPen(QColor("white")))
        p.setFont(QFont("Segoe UI Emoji", int(self._size * 0.38)))
        p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, self._emoji)


# ── Metric card ───────────────────────────────────────────────────────────────

class MetricCard(QWidget):
    _CFG = {
        "Total Patients":        ("👥", "#3b82f6",  "#1e3a5f"),
        "Today's Appointments":  ("📅", "#6366f1",  "#1e1e4a"),
        "Low Medicine Stock":    ("💊", "#f59e0b",  "#3d2f10"),
        "Active Queue":          ("🩺", "#10b981",  "#0d3028"),
        "Pending Clearances":    ("📋", "#8b5cf6",  "#2a1f45"),
        "Total Incidents":       ("⚠️",  "#ef4444",  "#3d1515"),
    }

    def __init__(self, title: str, value: str, change: str = ""):
        super().__init__()
        self.setObjectName("metric_card")
        self.setMinimumHeight(148)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

        emoji, icon_color, icon_bg = self._CFG.get(
            title, ("📊", "#3b82f6", "#1e3a5f")
        )

        root = QVBoxLayout(self)
        root.setContentsMargins(20, 18, 20, 16)
        root.setSpacing(0)

        # ── Top row: label + icon ──
        top = QHBoxLayout()
        top.setSpacing(0)

        lbl = QLabel(title)
        lbl.setObjectName("mc_label")
        top.addWidget(lbl)
        top.addStretch()

        ico = _IconCircle(emoji, icon_bg, 40)
        # thin coloured border
        ico_wrap = QWidget()
        ico_wrap.setFixedSize(42, 42)
        ico_wrap.setStyleSheet(
            f"border: 1px solid {icon_color}50; border-radius: 11px; background: transparent;"
        )
        ico_inner = QVBoxLayout(ico_wrap)
        ico_inner.setContentsMargins(1, 1, 1, 1)
        ico_inner.addWidget(ico)
        top.addWidget(ico_wrap)

        root.addLayout(top)
        root.addSpacing(12)

        # ── Value ──
        val = QLabel(value)
        val.setObjectName("mc_value")
        val_font = QFont("Segoe UI", 30)
        val_font.setBold(True)
        val.setFont(val_font)
        root.addWidget(val)
        root.addSpacing(8)

        # ── Delta row ──
        if change:
            d_row = QHBoxLayout()
            d_row.setSpacing(5)
            positive = "+" in change
            arrow    = "↑" if positive else "↓"
            obj      = "mc_delta_up" if positive else "mc_delta_down"
            stripped = change.lstrip("+-").strip()

            arr_lbl = QLabel(f"{arrow}  {stripped}")
            arr_lbl.setObjectName(obj)
            d_row.addWidget(arr_lbl)

            sub_lbl = QLabel("vs last week")
            sub_lbl.setObjectName("mc_delta_sub")
            d_row.addWidget(sub_lbl)
            d_row.addStretch()
            root.addLayout(d_row)

        root.addStretch()

        # Drop shadow
        fx = QGraphicsDropShadowEffect()
        fx.setBlurRadius(24)
        fx.setOffset(0, 6)
        fx.setColor(QColor("#00000050"))
        self.setGraphicsEffect(fx)


# ── Homepage ──────────────────────────────────────────────────────────────────

class HomePage(QWidget):
    """Full-page dashboard (no BasePage; owns its own scroll + layout)."""

    def __init__(self):
        super().__init__()
        # Use extracted stats class — fixes god-class concern
        self._stats = _Stats()
        self._init_ui()

    def _init_ui(self):
        page_layout = QVBoxLayout(self)
        page_layout.setContentsMargins(0, 0, 0, 0)
        page_layout.setSpacing(0)

        # scrollable body
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setObjectName("dash_scroll")

        body = QWidget()
        body.setObjectName("dash_body")
        body_layout = QVBoxLayout(body)
        body_layout.setContentsMargins(28, 24, 28, 28)
        body_layout.setSpacing(20)

        # ── Stats grid ──────────────────────────────────────────────────────
        metrics_grid = QGridLayout()
        metrics_grid.setSpacing(14)

        self._metric_data = [
            ("Total Patients",        self._count_patients(),           self._patients_change()),
            ("Today's Appointments",  self._count_today_appointments(), self._appointments_change()),
            ("Low Medicine Stock",    self._count_low_stock(),          self._low_stock_change()),
            ("Active Queue",          self._count_active_queue(),       self._active_queue_change()),
            ("Pending Clearances",    self._count_pending_clearances(), self._pending_clearances_change()),
            ("Total Incidents",       self._count_incidents(),          self._incidents_change()),
        ]
        r = c = 0
        for t, v, ch in self._metric_data:
            card = MetricCard(t, str(v), ch)
            metrics_grid.addWidget(card, r, c)
            c += 1
            if c >= 3:
                c = 0
                r += 1
        body_layout.addLayout(metrics_grid)

        # ── Two-column lower panels ──────────────────────────────────────────
        lower = QHBoxLayout()
        lower.setSpacing(14)

        lower.addWidget(self._build_appointments_panel(), 1)
        lower.addWidget(self._build_stock_panel(), 1)
        body_layout.addLayout(lower)

        body_layout.addStretch()
        scroll.setWidget(body)
        page_layout.addWidget(scroll)

    # ── Section builders ──────────────────────────────────────────────────────

    def _build_panel(self, icon: str, title: str, action_text: str = "View All") -> tuple:
        """Returns (panel_widget, content_layout, action_button)."""
        panel = QFrame()
        panel.setObjectName("section_panel")

        p_layout = QVBoxLayout(panel)
        p_layout.setContentsMargins(0, 0, 0, 0)
        p_layout.setSpacing(0)

        # header
        header = QWidget()
        header.setObjectName("section_header")
        h_row = QHBoxLayout(header)
        h_row.setContentsMargins(20, 14, 20, 14)
        h_row.setSpacing(10)

        ico_lbl = QLabel(icon)
        ico_lbl.setFont(QFont("Segoe UI Emoji", 15))
        ico_lbl.setStyleSheet("color: #3b82f6;")
        h_row.addWidget(ico_lbl)

        t_lbl = QLabel(title)
        t_lbl.setObjectName("section_title")
        h_row.addWidget(t_lbl)
        h_row.addStretch()

        action_btn = QPushButton(action_text)
        action_btn.setObjectName("section_action")
        action_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        h_row.addWidget(action_btn)

        p_layout.addWidget(header)

        # content area
        content = QWidget()
        c_layout = QVBoxLayout(content)
        c_layout.setContentsMargins(0, 0, 0, 0)
        c_layout.setSpacing(0)
        p_layout.addWidget(content, 1)

        return panel, c_layout, action_btn

    def _empty_state(self, icon: str, title: str, subtitle: str) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.setContentsMargins(20, 36, 20, 36)
        lay.setSpacing(8)

        ico = QLabel(icon)
        ico.setFont(QFont("Segoe UI Emoji", 36))
        ico.setAlignment(Qt.AlignmentFlag.AlignCenter)
        ico.setStyleSheet("color: rgba(107,122,150,0.35);")
        lay.addWidget(ico)

        t = QLabel(title)
        t.setObjectName("empty_title")
        t.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(t)

        s = QLabel(subtitle)
        s.setObjectName("empty_sub")
        s.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(s)
        return w

    def _build_appointments_panel(self) -> QFrame:
        panel, c_layout, _ = self._build_panel("📅", "Today's Appointments", "View All Appointments")
        appointments = self._get_today_appointments()
        if not appointments:
            c_layout.addWidget(
                self._empty_state("🗓", "No appointments scheduled for today", "You're all caught up!")
            )
        else:
            for appt in appointments[:5]:
                c_layout.addWidget(self._create_appointment_row(appt))
        c_layout.addStretch()
        return panel

    def _build_stock_panel(self) -> QFrame:
        panel, c_layout, _ = self._build_panel("📦", "Low Medicine Stock", "Manage Inventory")
        items = self._get_low_stock_items()
        if not items:
            c_layout.addWidget(
                self._empty_state("✅", "All inventory levels are healthy", "No reorders needed")
            )
        else:
            for item in items[:6]:
                c_layout.addWidget(self._create_stock_row(item))
        c_layout.addStretch()
        return panel

    # ── Row factories ─────────────────────────────────────────────────────────

    def _create_appointment_row(self, appt: dict) -> QFrame:
        frame = QFrame()
        frame.setObjectName("appt_row")
        lay = QHBoxLayout(frame)
        lay.setContentsMargins(20, 12, 20, 12)
        lay.setSpacing(12)

        # Avatar circle
        av = QLabel(appt.get("patient_name", "?")[:1].upper())
        av.setFixedSize(32, 32)
        av.setAlignment(Qt.AlignmentFlag.AlignCenter)
        av.setStyleSheet(
            "background: #1e3a5f; border-radius: 16px; color: #3b82f6;"
            " font-weight: 700; font-size: 13px;"
        )
        lay.addWidget(av)

        info = QVBoxLayout()
        info.setSpacing(2)
        name = QLabel(appt.get("patient_name", "Unknown"))
        name.setStyleSheet("color: #e2e8f0; font-weight: 600; font-size: 13px;")
        reason = QLabel(appt.get("reason", ""))
        reason.setStyleSheet("color: #6b7a96; font-size: 11px;")
        info.addWidget(name)
        info.addWidget(reason)
        lay.addLayout(info)
        lay.addStretch()

        dt = appt.get("date_time", "")
        time_str = dt.split()[-1] if " " in dt else ""
        t_lbl = QLabel(time_str)
        t_lbl.setStyleSheet("color: #94a3b8; font-size: 12px; font-weight: 600;")
        lay.addWidget(t_lbl)

        status = appt.get("status", "").lower()
        sc = {"confirmed": ("#10b981", "#0d3028"), "pending": ("#f59e0b", "#3d2f10")}
        fg, bg = sc.get(status, ("#64748b", "#1e2a3a"))
        s_lbl = QLabel(status.capitalize())
        s_lbl.setStyleSheet(
            f"color:{fg}; background:{bg}; border-radius:5px;"
            " padding:3px 10px; font-size:11px; font-weight:600;"
        )
        lay.addWidget(s_lbl)
        return frame

    def _create_stock_row(self, item: dict) -> QFrame:
        frame = QFrame()
        frame.setObjectName("appt_row")
        lay = QHBoxLayout(frame)
        lay.setContentsMargins(20, 12, 20, 12)
        lay.setSpacing(12)

        warn = QLabel("⚠")
        warn.setStyleSheet("color: #f59e0b; font-size: 16px;")
        lay.addWidget(warn)

        info = QVBoxLayout()
        info.setSpacing(2)
        name = QLabel(item.get("name", "Unknown"))
        name.setStyleSheet("color: #e2e8f0; font-weight: 600; font-size: 13px;")
        note = QLabel("Reorder needed")
        note.setStyleSheet("color: #6b7a96; font-size: 11px;")
        info.addWidget(name)
        info.addWidget(note)
        lay.addLayout(info)
        lay.addStretch()

        qty = f"{item.get('quantity', 0)} / {item.get('reorder_level', 0)} {item.get('unit', '')}"
        q_lbl = QLabel(qty)
        q_lbl.setStyleSheet(
            "color:#ef4444; background:#3d1515; border-radius:5px;"
            " padding:3px 10px; font-size:11px; font-weight:700;"
        )
        lay.addWidget(q_lbl)
        return frame

    # ── Counters & change calculations ───────────────────────────────────────

    @staticmethod
    def _week_range(weeks_ago: int = 0):
        """Return (start_date, end_date) as date objects for a given week offset."""
        today = datetime.date.today()
        # Start of current week = today - weekday (Monday=0)
        start_of_this_week = today - datetime.timedelta(days=today.weekday())
        start = start_of_this_week - datetime.timedelta(weeks=weeks_ago)
        end   = start + datetime.timedelta(days=6)
        return start, end

    @staticmethod
    def _fmt_change(current: int, previous: int, unit: str = "") -> str:
        """Return a formatted change string like '+3 vs last week' or '-12.5% vs last week'."""
        diff = current - previous
        if previous == 0:
            if diff == 0:
                return "No change vs last week"
            label = f"+{diff}{unit}" if diff > 0 else f"{diff}{unit}"
            return f"{label} vs last week"
        pct = (diff / previous) * 100
        sign = "+" if pct >= 0 else ""
        return f"{sign}{pct:.1f}% vs last week"

    def _count_patients(self) -> int:
        try:
            with open(PATIENTS_CSV, "r", encoding="utf-8") as f:
                return sum(1 for _ in csv.DictReader(f))
        except (FileNotFoundError, IOError):
            return 0

    def _count_patients_added_in_week(self, start, end) -> int:
        """Count patients whose patient_id timestamp falls within the week."""
        # patient_id is like "P<timestamp_ms>" — we extract the timestamp
        count = 0
        try:
            with open(PATIENTS_CSV, "r", encoding="utf-8") as f:
                for row in csv.DictReader(f):
                    pid = row.get("patient_id", "")
                    # Try to extract numeric timestamp from id
                    digits = ''.join(c for c in pid if c.isdigit())
                    if digits and len(digits) >= 10:
                        try:
                            # Could be ms timestamp
                            ts = int(digits[:13]) / 1000 if len(digits) >= 13 else int(digits[:10])
                            dt = datetime.date.fromtimestamp(ts)
                            if start <= dt <= end:
                                count += 1
                        except Exception:
                            pass
        except (FileNotFoundError, IOError):
            pass
        return count

    def _patients_change(self) -> str:
        this_start, this_end = self._week_range(0)
        last_start, last_end = self._week_range(1)
        this_week = self._count_patients_added_in_week(this_start, this_end)
        last_week = self._count_patients_added_in_week(last_start, last_end)
        return self._fmt_change(this_week, last_week)

    def _count_today_appointments(self) -> int:
        today = _dt.now().strftime("%Y-%m-%d")
        count = 0
        try:
            with open(APPOINTMENTS_CSV, "r", encoding="utf-8") as f:
                for row in csv.DictReader(f):
                    if row.get("date_time", "").startswith(today):
                        count += 1
        except (FileNotFoundError, IOError):
            pass
        return count

    def _count_appointments_in_week(self, start, end) -> int:
        count = 0
        try:
            with open(APPOINTMENTS_CSV, "r", encoding="utf-8") as f:
                for row in csv.DictReader(f):
                    dt_str = row.get("date_time", "").split(" ")[0]
                    try:
                        dt = datetime.date.fromisoformat(dt_str)
                        if start <= dt <= end:
                            count += 1
                    except ValueError:
                        pass
        except (FileNotFoundError, IOError):
            pass
        return count

    def _appointments_change(self) -> str:
        this_start, this_end = self._week_range(0)
        last_start, last_end = self._week_range(1)
        this_week = self._count_appointments_in_week(this_start, this_end)
        last_week = self._count_appointments_in_week(last_start, last_end)
        return self._fmt_change(this_week, last_week)

    def _count_low_stock(self) -> int:
        count = 0
        try:
            with open(INVENTORY_CSV, "r", encoding="utf-8") as f:
                for row in csv.DictReader(f):
                    try:
                        qty     = float(row.get("quantity", 0))
                        reorder = float(row.get("reorder_level", 0))
                        if qty <= reorder:
                            count += 1
                    except (ValueError, TypeError):
                        pass
        except (FileNotFoundError, IOError):
            pass
        return count

    def _low_stock_change(self) -> str:
        # Low stock doesn't have a date — compare absolute count to a snapshot
        # We show the raw count diff as items (no time window for inventory)
        current = self._count_low_stock()
        # Since inventory has no timestamps, we show the count as-is with a neutral label
        if current == 0:
            return "All stock healthy"
        elif current == 1:
            return f"{current} item needs reorder"
        else:
            return f"{current} items need reorder"

    def _count_consultations(self) -> int:
        count = 0
        try:
            with open(APPOINTMENTS_CSV, "r", encoding="utf-8") as f:
                for row in csv.DictReader(f):
                    if row.get("status", "").lower() == "pending":
                        count += 1
        except (FileNotFoundError, IOError):
            pass
        return count

    def _count_pending_in_week(self, start, end) -> int:
        count = 0
        try:
            with open(APPOINTMENTS_CSV, "r", encoding="utf-8") as f:
                for row in csv.DictReader(f):
                    if row.get("status", "").lower() != "pending":
                        continue
                    dt_str = row.get("date_time", "").split(" ")[0]
                    try:
                        dt = datetime.date.fromisoformat(dt_str)
                        if start <= dt <= end:
                            count += 1
                    except ValueError:
                        pass
        except (FileNotFoundError, IOError):
            pass
        return count

    def _consultations_change(self) -> str:
        this_start, this_end = self._week_range(0)
        last_start, last_end = self._week_range(1)
        this_week = self._count_pending_in_week(this_start, this_end)
        last_week = self._count_pending_in_week(last_start, last_end)
        return self._fmt_change(this_week, last_week)

    def _count_vaccinations(self) -> int:
        try:
            with open(VACCINES_CSV, "r", encoding="utf-8") as f:
                return sum(1 for _ in csv.DictReader(f))
        except (FileNotFoundError, IOError):
            return 0

    def _count_vaccines_in_week(self, start, end) -> int:
        count = 0
        try:
            with open(VACCINES_CSV, "r", encoding="utf-8") as f:
                for row in csv.DictReader(f):
                    dt_str = row.get("date_given", "")
                    try:
                        dt = datetime.date.fromisoformat(dt_str)
                        if start <= dt <= end:
                            count += 1
                    except ValueError:
                        pass
        except (FileNotFoundError, IOError):
            pass
        return count

    def _vaccinations_change(self) -> str:
        this_start, this_end = self._week_range(0)
        last_start, last_end = self._week_range(1)
        this_week = self._count_vaccines_in_week(this_start, this_end)
        last_week = self._count_vaccines_in_week(last_start, last_end)
        return self._fmt_change(this_week, last_week)

    # ── Active Queue ──────────────────────────────────────────────────────────

    def _count_active_queue(self) -> int:
        """Count patients currently waiting or being seen in the queue."""
        count = 0
        try:
            with open(QUEUE_CSV, "r", encoding="utf-8") as f:
                for row in csv.DictReader(f):
                    if row.get("status", "").lower() in ("waiting", "in progress"):
                        count += 1
        except (FileNotFoundError, IOError):
            pass
        return count

    def _count_queue_in_week(self, start, end) -> int:
        count = 0
        try:
            with open(QUEUE_CSV, "r", encoding="utf-8") as f:
                for row in csv.DictReader(f):
                    dt_str = row.get("checkin_time", "").split(" ")[0]
                    try:
                        dt = datetime.date.fromisoformat(dt_str)
                        if start <= dt <= end:
                            count += 1
                    except ValueError:
                        pass
        except (FileNotFoundError, IOError):
            pass
        return count

    def _active_queue_change(self) -> str:
        current = self._count_active_queue()
        if current == 0:
            return "Queue is clear"
        elif current == 1:
            return f"{current} patient waiting"
        else:
            return f"{current} patients waiting"

    # ── Pending Clearances ────────────────────────────────────────────────────

    def _count_pending_clearances(self) -> int:
        """Count clearances with 'pending' status."""
        count = 0
        try:
            with open(CLEARANCE_CSV, "r", encoding="utf-8") as f:
                for row in csv.DictReader(f):
                    if row.get("status", "").lower() == "pending":
                        count += 1
        except (FileNotFoundError, IOError):
            pass
        return count

    def _count_clearances_in_week(self, start, end) -> int:
        count = 0
        try:
            with open(CLEARANCE_CSV, "r", encoding="utf-8") as f:
                for row in csv.DictReader(f):
                    if row.get("status", "").lower() != "pending":
                        continue
                    dt_str = row.get("date", "")
                    try:
                        dt = datetime.date.fromisoformat(dt_str)
                        if start <= dt <= end:
                            count += 1
                    except ValueError:
                        pass
        except (FileNotFoundError, IOError):
            pass
        return count

    def _pending_clearances_change(self) -> str:
        this_start, this_end = self._week_range(0)
        last_start, last_end = self._week_range(1)
        this_week = self._count_clearances_in_week(this_start, this_end)
        last_week = self._count_clearances_in_week(last_start, last_end)
        return self._fmt_change(this_week, last_week)

    def _count_incidents(self) -> int:
        try:
            with open(INCIDENTS_CSV, "r", encoding="utf-8") as f:
                return sum(1 for _ in csv.DictReader(f))
        except (FileNotFoundError, IOError):
            return 0

    def _count_incidents_in_week(self, start, end) -> int:
        count = 0
        try:
            with open(INCIDENTS_CSV, "r", encoding="utf-8") as f:
                for row in csv.DictReader(f):
                    dt_str = row.get("date", "")
                    try:
                        dt = datetime.date.fromisoformat(dt_str)
                        if start <= dt <= end:
                            count += 1
                    except ValueError:
                        pass
        except (FileNotFoundError, IOError):
            pass
        return count

    def _incidents_change(self) -> str:
        this_start, this_end = self._week_range(0)
        last_start, last_end = self._week_range(1)
        this_week = self._count_incidents_in_week(this_start, this_end)
        last_week = self._count_incidents_in_week(last_start, last_end)
        return self._fmt_change(this_week, last_week)

    def _get_today_appointments(self) -> list:
        result, today = [], _dt.now().strftime("%Y-%m-%d")
        try:
            with open(APPOINTMENTS_CSV, "r", encoding="utf-8") as f:
                for row in csv.DictReader(f):
                    if row.get("date_time", "").startswith(today):
                        result.append({
                            "patient_name": self._get_patient_name(row.get("patient_id", "")),
                            "reason":    row.get("reason", ""),
                            "date_time": row.get("date_time", ""),
                            "status":    row.get("status", ""),
                        })
        except (FileNotFoundError, IOError):
            pass
        return sorted(result, key=lambda x: x["date_time"])

    def _get_patient_name(self, pid: str) -> str:
        try:
            with open(PATIENTS_CSV, "r", encoding="utf-8") as f:
                for row in csv.DictReader(f):
                    if row.get("patient_id") == pid:
                        return f"{row.get('first_name','')} {row.get('last_name','')}".strip() or pid
        except (FileNotFoundError, IOError):
            pass
        return pid

    def _get_low_stock_items(self) -> list:
        result = []
        try:
            with open(INVENTORY_CSV, "r", encoding="utf-8") as f:
                for row in csv.DictReader(f):
                    try:
                        qty     = float(row.get("quantity", "0"))
                        reorder = float(row.get("reorder_level", "0"))
                        if qty <= reorder:
                            result.append({
                                "name":          row.get("name", ""),
                                "quantity":      int(qty),
                                "unit":          row.get("unit", ""),
                                "reorder_level": int(reorder),
                            })
                    except (ValueError, TypeError):
                        pass
        except (FileNotFoundError, IOError):
            pass
        return sorted(result, key=lambda x: x["quantity"])

    def load_data(self):
        """Refresh all dashboard stats and panels in-place."""
        self._refresh_dashboard()

    def _refresh_dashboard(self):
        """Rebuild the full dashboard body in-place."""
        # Wipe and re-create body content
        old_scroll = self.layout().itemAt(0).widget()
        self.layout().removeWidget(old_scroll)
        old_scroll.deleteLater()

        # Re-run _init_ui to recreate everything fresh
        body = QWidget()
        body.setObjectName("dash_body")
        body_layout = QVBoxLayout(body)
        body_layout.setContentsMargins(28, 24, 28, 28)
        body_layout.setSpacing(20)

        self._metric_data = [
            ("Total Patients",        self._count_patients(),           self._patients_change()),
            ("Today's Appointments",  self._count_today_appointments(), self._appointments_change()),
            ("Low Medicine Stock",    self._count_low_stock(),          self._low_stock_change()),
            ("Active Queue",          self._count_active_queue(),       self._active_queue_change()),
            ("Pending Clearances",    self._count_pending_clearances(), self._pending_clearances_change()),
            ("Total Incidents",       self._count_incidents(),          self._incidents_change()),
        ]
        metrics_grid = QGridLayout()
        metrics_grid.setSpacing(14)
        r = c = 0
        for t, v, ch in self._metric_data:
            card = MetricCard(t, str(v), ch)
            metrics_grid.addWidget(card, r, c)
            c += 1
            if c >= 3:
                c = 0; r += 1
        body_layout.addLayout(metrics_grid)

        lower = QHBoxLayout()
        lower.setSpacing(14)
        lower.addWidget(self._build_appointments_panel(), 1)
        lower.addWidget(self._build_stock_panel(), 1)
        body_layout.addLayout(lower)
        body_layout.addStretch()

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setObjectName("dash_scroll")
        scroll.setWidget(body)
        self.layout().addWidget(scroll)

# =============================================================================
