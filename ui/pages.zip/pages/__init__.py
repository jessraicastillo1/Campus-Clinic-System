from ui.pages.home_page import HomePage
from ui.pages.patient_page import PatientPage
from ui.pages.history_page import HistoryPage
from ui.pages.emergency_page import EmergencyPage
from ui.pages.vaccines_page import VaccinesPage
from ui.pages.vitals_page import VitalsPage
from ui.pages.prescriptions_page import PrescriptionsPage
from ui.pages.referrals_page import ReferralsPage
from ui.pages.inventory_page import InventoryPage
from ui.pages.dispense_page import DispensePage
from ui.pages.appointments_page import AppointmentsPage
from ui.pages.queue_page import QueuePage
from ui.pages.clearances_page import ClearancesPage
from ui.pages.absences_page import AbsencesPage
from ui.pages.incidents_page import IncidentsPage

__all__ = [
    "HomePage", "PatientPage", "HistoryPage", "EmergencyPage",
    "VaccinesPage", "VitalsPage", "PrescriptionsPage", "ReferralsPage",
    "InventoryPage", "DispensePage", "AppointmentsPage", "QueuePage",
    "ClearancesPage", "AbsencesPage", "IncidentsPage",
]
from ui.pages.audit_page import AuditPage
__all__.append("AuditPage")
from ui.pages.users_page import UsersPage
__all__.append("UsersPage")
