import os, sys, csv, datetime, hashlib
from datetime import datetime as _dt

from PyQt6.QtCore import Qt, QSize, QDate
from PyQt6.QtGui import QColor, QFont, QIcon, QLinearGradient, QBrush, QPainter, QPen
from PyQt6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QDateEdit, QDialog, QDialogButtonBox,
    QFormLayout, QFrame, QGraphicsDropShadowEffect, QGridLayout,
    QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem,
    QMainWindow, QMessageBox, QPushButton, QScrollArea,
    QStackedWidget, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from backend.config import *
from backend.utils import *
from backend.database import *
from backend.auth import *
from backend.inventory import *
from backend.queue_logic import *
from ui.pages.base_page import BasePage

# =============================================================================


class TablePage(BasePage):

    DEFAULT_HEADERS = []

    # Subclasses declare which column keys are PHI / sensitive.
    # For viewer accounts these cells are replaced with "••••••" in the UI.
    SENSITIVE_COLUMNS: list = []

    def __init__(self, title: str, csv_path: str, role: str = "viewer", username: str = ""):
        self._csv_path   = csv_path
        self._role       = role.lower()
        self._username   = username
        self._table      = None
        self._headers    = []
        self._all_rows   = []   # full dataset for client-side search
        super().__init__(title)
        self._init_content()
        self._apply_role_permissions()
        self.load_data()

    def _init_content(self):
        # ── Search bar ────────────────────────────────────────────────────────
        search_row = QHBoxLayout()
        self._search_box = QLineEdit()
        self._search_box.setPlaceholderText("🔍  Search…")
        self._search_box.setClearButtonEnabled(True)
        self._search_box.textChanged.connect(self._apply_filter)
        search_row.addWidget(self._search_box)
        self.body_layout.addLayout(search_row)

        # ── Buttons ───────────────────────────────────────────────────────────
        controls_layout = QHBoxLayout()
        self._add_button = QPushButton("➕  Add")
        self._add_button.clicked.connect(self.on_add)
        controls_layout.addWidget(self._add_button)

        self._edit_button = QPushButton("✏️  Edit")
        self._edit_button.clicked.connect(self.on_edit)
        controls_layout.addWidget(self._edit_button)

        self._delete_button = QPushButton("🗑  Delete")
        self._delete_button.clicked.connect(self.on_delete)
        controls_layout.addWidget(self._delete_button)

        self._print_button = QPushButton("🖨  Print")
        self._print_button.clicked.connect(self.on_print)
        controls_layout.addWidget(self._print_button)

        refresh_button = QPushButton("🔄  Refresh")
        refresh_button.clicked.connect(self.load_data)
        controls_layout.addWidget(refresh_button)
        controls_layout.addStretch()

        self._row_count_label = QLabel("")
        self._row_count_label.setObjectName("rowCountLabel")
        controls_layout.addWidget(self._row_count_label)

        self.body_layout.addLayout(controls_layout)

        # ── Table ─────────────────────────────────────────────────────────────
        self._table = QTableWidget()
        self._table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self._table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self._table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        self._table.setSortingEnabled(True)
        self.body_layout.addWidget(self._table)

    # ── Role permissions ─────────────────────────────────────────────────────

    def _apply_role_permissions(self):
        """Hide write buttons entirely for viewer role; admins/staff see all."""
        can_write = self._role in ("admin", "staff")
        # Completely hide Add / Edit / Delete for viewers — a greyed-out button
        # is confusing; viewers are read-only so the buttons serve no purpose.
        self._add_button.setVisible(can_write)
        self._edit_button.setVisible(can_write)
        self._delete_button.setVisible(can_write)

    # ── Data loading ──────────────────────────────────────────────────────────

    def load_data(self):
        self._all_rows = read_csv(self._csv_path)
        self._headers  = list(self._all_rows[0].keys()) if self._all_rows else self.DEFAULT_HEADERS
        self._apply_filter(self._search_box.text() if self._search_box else "")

    def _apply_filter(self, text: str):
        """Filter _all_rows by search text and redisplay.
        Sensitive columns are masked with '\u2022\u2022\u2022\u2022\u2022\u2022' for viewer accounts."""
        is_viewer = self._role == "viewer"
        sensitive = set(self.SENSITIVE_COLUMNS)

        term = text.strip().lower()
        if term:
            # Search only non-sensitive values for viewers so masked data
            # can't be probed via the search box.
            filtered = [
                row for row in self._all_rows
                if any(
                    term in str(v).lower()
                    for k, v in row.items()
                    if not (is_viewer and k in sensitive)
                )
            ]
        else:
            filtered = self._all_rows

        self._table.setSortingEnabled(False)
        self._table.setColumnCount(len(self._headers))
        self._table.setRowCount(len(filtered))
        self._table.setHorizontalHeaderLabels(
            [h.replace("_", " ").title() for h in self._headers]
        )
        for row_index, row in enumerate(filtered):
            for col_index, header in enumerate(self._headers):
                if is_viewer and header in sensitive:
                    display = "\u2022\u2022\u2022\u2022\u2022\u2022"
                else:
                    display = row.get(header, "")
                item = QTableWidgetItem(display)
                item.setFlags(Qt.ItemFlag.ItemIsSelectable | Qt.ItemFlag.ItemIsEnabled)
                if is_viewer and header in sensitive:
                    item.setForeground(QColor("#4b5563"))
                self._table.setItem(row_index, col_index, item)
        self._table.resizeColumnsToContents()
        self._table.resizeRowsToContents()
        self._table.setSortingEnabled(True)

        total = len(self._all_rows)
        shown = len(filtered)
        if self._row_count_label:
            label = f"{shown} of {total} records" if term else f"{total} records"
            if is_viewer and sensitive:
                label += "  \U0001f512 Some fields are hidden"
            self._row_count_label.setText(label)

    def selected_row_data(self):
        row_index = self._table.currentRow()
        if row_index < 0:
            return None
        return {
            self._headers[col_index]: self._table.item(row_index, col_index).text()
            for col_index in range(self._table.columnCount())
        }

    # ── Overridable actions ───────────────────────────────────────────────────

    def on_add(self):
        QMessageBox.information(self, "Not Implemented", "Add is not implemented for this module yet.")

    def on_edit(self):
        QMessageBox.information(self, "Not Implemented", "Edit is not implemented for this module yet.")

    def on_delete(self):
        QMessageBox.information(self, "Not Implemented", "Delete is not implemented for this module yet.")

    def on_print(self):
        """Generate a simple HTML print preview and open it in the system browser.
        Sensitive columns are masked for viewer accounts."""
        import tempfile, webbrowser, html as html_mod
        rows = self._all_rows
        if not rows:
            QMessageBox.information(self, "Print", "No data to print.")
            return

        is_viewer = self._role == "viewer"
        sensitive = set(self.SENSITIVE_COLUMNS)
        headers = self._headers
        title   = self._title

        th = "".join(f"<th>{html_mod.escape(h.replace('_',' ').title())}</th>" for h in headers)
        trs = ""
        for row in rows:
            tds = ""
            for h in headers:
                if is_viewer and h in sensitive:
                    cell = "\u2022\u2022\u2022\u2022\u2022\u2022"
                    tds += f'<td style="color:#9ca3af">{cell}</td>'
                else:
                    tds += f"<td>{html_mod.escape(row.get(h,''))}</td>"
            trs += f"<tr>{tds}</tr>\n"

        html_content = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8">
<title>{html_mod.escape(title)}</title>
<style>
  body {{ font-family: Arial, sans-serif; font-size: 12px; margin: 20px; }}
  h2   {{ color: #1e3a5f; }}
  table{{ border-collapse: collapse; width: 100%; }}
  th   {{ background: #1e3a5f; color: white; padding: 6px 8px; text-align: left; }}
  td   {{ border: 1px solid #ccc; padding: 5px 8px; }}
  tr:nth-child(even) {{ background: #f5f7fa; }}
  .meta {{ color: #666; font-size: 11px; margin-bottom: 10px; }}
</style></head>
<body>
<h2>Campus Clinic — {html_mod.escape(title)}</h2>
<p class="meta">Printed: {_dt.now().strftime('%Y-%m-%d %H:%M')} &nbsp;|&nbsp; {len(rows)} records</p>
<table><thead><tr>{th}</tr></thead><tbody>{trs}</tbody></table>
</body></html>"""

        with tempfile.NamedTemporaryFile(mode="w", suffix=".html",
                                         delete=False, encoding="utf-8") as f:
            f.write(html_content)
            tmp_path = f.name

        webbrowser.open(f"file://{tmp_path}")

# =============================================================================
