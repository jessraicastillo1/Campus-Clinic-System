"""history_page.py — Medical History CRUD with redesigned Royal Dark form."""

from __future__ import annotations
import datetime

from PyQt6.QtCore    import Qt, QDate
from PyQt6.QtWidgets import (
    QComboBox, QDialog, QHBoxLayout, QLabel, QLineEdit,
    QMessageBox, QPushButton, QVBoxLayout, QWidget,
)

from backend.config   import HISTORY_CSV
from backend.utils    import new_id
from backend.database import append_csv, read_csv, update_row, delete_rows, log_audit
from ui.pages.base_page  import BasePage
from ui.pages.table_page import TablePage
from ui.pages._dialog_base import _BaseFormDialog


# =============================================================================

class HistoryFormDialog(_BaseFormDialog):

    def __init__(self, parent=None, data: dict | None = None,
                 session_user: str = ""):
        super().__init__(parent, data, session_user)
        title = "Edit Medical Record" if data else "Add Medical Record"
        self._build_ui(title, bar_color="#1a3a8a")

    # ── form construction ─────────────────────────────────────────────────

    def _populate_form(self) -> None:
        d = self._data

        # ── AUTO section ──
        self._section("Auto")

        rid = d.get("record_id", "")
        self._f_record_id = self._ro_field(rid or "Auto-generated")
        self._row("Record ID", self._f_record_id)

        self._f_patient = self._patient_combo(d.get("patient_id", ""))
        self._row("Patient ID", self._f_patient, required=True)

        self._spacer()

        # ── VISIT section ──
        self._section("Visit")

        self._f_visit_date = self._date_field(
            self._date_from_str(d.get("visit_date", "")))
        self._row("Visit Date", self._f_visit_date, required=True)

        self._f_complaint = self._textarea(3, "e.g. Headache, fever since 2 days")
        self._f_complaint.setPlainText(d.get("complaint", ""))
        self._row("Complaint", self._f_complaint, required=True)

        self._f_diagnosis = self._textarea(3, "e.g. Viral pharyngitis")
        self._f_diagnosis.setPlainText(d.get("diagnosis", ""))
        self._row("Diagnosis", self._f_diagnosis, required=True)

        self._f_treatment = self._textarea(3, "e.g. Rest, fluids, paracetamol")
        self._f_treatment.setPlainText(d.get("treatment", ""))
        self._row("Treatment", self._f_treatment)

        self._f_notes = self._textarea(2, "Optional notes…")
        self._f_notes.setPlainText(d.get("notes", ""))
        self._row("Notes", self._f_notes)

        self._spacer()

        # ── STAFF section ──
        self._section("Staff")

        self._f_staff = self._ro_field(d.get("staff_user", self._session_user))
        self._row("Staff User", self._f_staff)

    # ── validation & save ─────────────────────────────────────────────────

    def _on_save(self) -> None:
        pid = self._patient_id_from_combo(self._f_patient)
        if not pid:
            QMessageBox.warning(self, "Required", "Patient ID is required.")
            return
        if not self._f_complaint.toPlainText().strip():
            QMessageBox.warning(self, "Required", "Complaint is required.")
            return
        if not self._f_diagnosis.toPlainText().strip():
            QMessageBox.warning(self, "Required", "Diagnosis is required.")
            return

        rid = self._data.get("record_id", "") or new_id("MH")
        self._show_toast(f"Medical record {rid} saved successfully")
        self._f_record_id.setText(rid)
        self._saved_id = rid
        from PyQt6.QtCore import QTimer
        from PyQt6.QtWidgets import QDialog
        QTimer.singleShot(400, self.accept)

    def get_data(self) -> dict:
        return {
            "record_id":  self._data.get("record_id", "") or getattr(self, "_saved_id", new_id("MH")),
            "patient_id": self._patient_id_from_combo(self._f_patient),
            "visit_date": self._f_visit_date.date().toString("yyyy-MM-dd"),
            "complaint":  self._f_complaint.toPlainText().strip(),
            "diagnosis":  self._f_diagnosis.toPlainText().strip(),
            "treatment":  self._f_treatment.toPlainText().strip(),
            "notes":      self._f_notes.toPlainText().strip(),
            "staff_user": self._f_staff.text().strip(),
        }


# =============================================================================

class HistoryPage(TablePage):
    DEFAULT_HEADERS = [
        "record_id", "patient_id", "visit_date", "complaint",
        "diagnosis", "treatment", "notes", "staff_user",
    ]
    SENSITIVE_COLUMNS = ["complaint", "diagnosis", "treatment", "notes"]

    def __init__(self, role: str = "viewer", username: str = ""):
        super().__init__("Medical History", HISTORY_CSV, role, username)

    def on_add(self):
        dialog = HistoryFormDialog(self, session_user=self._username)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        row = dialog.get_data()
        if not row.get("record_id"):
            row["record_id"] = new_id("MH")
        append_csv(HISTORY_CSV, row, headers=self.DEFAULT_HEADERS)
        log_audit(self._username, "ADD", "History", row["record_id"], row.get("patient_id", ""))
        self.load_data()

    def on_edit(self):
        row_data = self.selected_row_data()
        if not row_data:
            QMessageBox.warning(self, "Select Record", "Please select a record to edit.")
            return
        dialog = HistoryFormDialog(self, row_data, session_user=self._username)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        updated_row = dialog.get_data()
        rid = row_data.get("record_id")
        updated = update_row(HISTORY_CSV, lambda r: r.get("record_id") == rid,
                             updated_row, headers=self.DEFAULT_HEADERS)
        if not updated:
            QMessageBox.warning(self, "Update Failed", "Could not update the record.")
            return
        log_audit(self._username, "EDIT", "History", rid, "")
        self.load_data()

    def on_delete(self):
        row_data = self.selected_row_data()
        if not row_data:
            QMessageBox.warning(self, "Select Record", "Please select a record to delete.")
            return
        answer = QMessageBox.question(
            self, "Delete Record",
            f"Delete medical record for patient {row_data.get('patient_id', '')}?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        rid = row_data.get("record_id")
        deleted = delete_rows(HISTORY_CSV, lambda r: r.get("record_id") == rid,
                              headers=self.DEFAULT_HEADERS)
        if not deleted:
            QMessageBox.warning(self, "Delete Failed", "Could not delete the record.")
            return
        log_audit(self._username, "DELETE", "History", rid, "")
        self.load_data()
