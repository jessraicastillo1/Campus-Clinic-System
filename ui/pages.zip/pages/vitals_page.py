"""vitals_page.py — Vitals CRUD with redesigned Royal Dark form."""

from __future__ import annotations
import datetime

from PyQt6.QtCore    import Qt, QDate
from PyQt6.QtWidgets import (
    QDialog, QHBoxLayout, QLabel, QMessageBox, QWidget,
)

from backend.config   import VITALS_CSV
from backend.utils    import new_id, calc_bmi
from backend.database import append_csv, update_row, delete_rows, log_audit
from backend.models   import Vital
from ui.pages.table_page   import TablePage
from ui.pages._dialog_base import _BaseFormDialog

# =============================================================================

class VitalFormDialog(_BaseFormDialog):

    def __init__(self, parent=None, data: dict | None = None,
                 session_user: str = ""):
        super().__init__(parent, data, session_user)
        title = "Edit Vitals" if data else "Add Vitals"
        self._build_ui(title, bar_color="#1a3a8a")

    def _populate_form(self) -> None:
        d = self._data

        # ── AUTO ──
        self._section("Auto")
        self._f_record_id = self._ro_field(d.get("record_id", "") or "Auto-generated")
        self._row("Vital ID", self._f_record_id)
        self._f_patient = self._patient_combo(d.get("patient_id", ""))
        self._row("Patient ID", self._f_patient, required=True)
        self._spacer()

        # ── MEASUREMENTS ──
        self._section("Measurements")

        raw_dt = d.get("date_time", "")
        date_part = raw_dt.split(" ")[0] if raw_dt else ""
        time_part = raw_dt.split(" ")[1] if " " in raw_dt else datetime.datetime.now().strftime("%H:%M")

        self._f_date = self._date_field(self._date_from_str(date_part))
        self._row("Date Taken", self._f_date, required=True)

        self._f_time = self._text_field("HH:MM", time_part)
        self._row("Time", self._f_time)

        def _try_float(key, default=0.0):
            try: return float(d.get(key, default) or default)
            except: return default

        self._f_height = self._double_spinbox(0, 250, _try_float("height_cm"), 1, "cm")
        self._row("Height", self._f_height)

        self._f_weight = self._double_spinbox(0, 300, _try_float("weight_kg"), 1, "kg")
        self._row("Weight", self._f_weight)

        # BMI pill row
        self._bmi_pill = QLabel("—")
        self._bmi_pill.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._bmi_pill.setFixedHeight(30)
        self._bmi_pill.setMinimumWidth(80)
        self._bmi_pill.setStyleSheet(
            "background:#1a3a8a20; color:#1a3a8a; border:1px solid #1a3a8a60;"
            " border-radius:15px; padding:0 14px; font-size:12px; font-weight:700;"
        )
        self._row("BMI (auto)", self._bmi_pill)
        self._f_bmi_val = self._ro_field(d.get("bmi", ""))
        self._f_bmi_val.hide()  # hidden, used for get_data()

        self._f_bp_systolic  = self._double_spinbox(0, 300, _try_float("bp_systolic"),  0)
        self._row("BP Systolic", self._f_bp_systolic)
        self._f_bp_diastolic = self._double_spinbox(0, 200, _try_float("bp_diastolic"), 0)
        self._row("BP Diastolic", self._f_bp_diastolic)
        self._f_temp = self._double_spinbox(30, 45, _try_float("temperature_c", 36.5), 1, "°C")
        self._row("Temperature", self._f_temp)

        self._spacer()
        self._section("Notes")
        self._f_notes  = self._textarea(2, "Optional notes…")
        self._f_notes.setPlainText(d.get("notes", ""))
        self._row("Notes", self._f_notes)
        self._f_staff  = self._ro_field(d.get("staff_user", self._session_user))
        self._row("Staff User", self._f_staff)

        # connect live BMI
        self._f_height.valueChanged.connect(self._update_bmi)
        self._f_weight.valueChanged.connect(self._update_bmi)
        if d.get("height_cm") or d.get("weight_kg"):
            self._update_bmi()

    def _update_bmi(self) -> None:
        h = self._f_height.value()
        w = self._f_weight.value()
        bmi = calc_bmi(h, w)
        if bmi == "" or h == 0 or w == 0:
            self._bmi_pill.setText("—")
            self._bmi_pill.setStyleSheet(
                "background:#1a3a8a20; color:#1a3a8a; border:1px solid #1a3a8a60;"
                " border-radius:15px; padding:0 14px; font-size:12px; font-weight:700;"
            )
            self._f_bmi_val.setText("")
            return
        bmi = float(bmi)
        self._f_bmi_val.setText(str(bmi))
        if bmi < 18.5:
            col = "#c9a227"
            cat = f"{bmi} Underweight"
        elif bmi < 25:
            col = "#1a7a4a"
            cat = f"{bmi} Normal"
        elif bmi < 30:
            col = "#e67e22"
            cat = f"{bmi} Overweight"
        else:
            col = "#c0392b"
            cat = f"{bmi} Obese"
        self._bmi_pill.setText(cat)
        self._bmi_pill.setStyleSheet(
            f"background:{col}20; color:{col}; border:1px solid {col}60;"
            " border-radius:15px; padding:0 14px; font-size:12px; font-weight:700;"
        )

    def _on_save(self) -> None:
        pid = self._patient_id_from_combo(self._f_patient)
        if not pid:
            QMessageBox.warning(self, "Required", "Patient ID is required.")
            return
        self._show_toast("Vitals recorded successfully")
        from PyQt6.QtCore import QTimer
        QTimer.singleShot(400, self.accept)

    def get_data(self) -> dict:
        date_str = self._f_date.date().toString("yyyy-MM-dd")
        time_str = self._f_time.text().strip() or "00:00"
        return {
            "record_id":    self._data.get("record_id", "") or new_id("VT"),
            "patient_id":   self._patient_id_from_combo(self._f_patient),
            "date_time":    f"{date_str} {time_str}",
            "height_cm":    str(self._f_height.value()),
            "weight_kg":    str(self._f_weight.value()),
            "bmi":          self._f_bmi_val.text(),
            "bp_systolic":  str(int(self._f_bp_systolic.value())),
            "bp_diastolic": str(int(self._f_bp_diastolic.value())),
            "temperature_c":str(self._f_temp.value()),
            "notes":        self._f_notes.toPlainText().strip(),
            "staff_user":   self._f_staff.text(),
        }


# =============================================================================

class VitalsPage(TablePage):
    DEFAULT_HEADERS = [
        "record_id", "patient_id", "date_time", "height_cm",
        "weight_kg", "bmi", "bp_systolic", "bp_diastolic", "temperature_c",
    ]
    SENSITIVE_COLUMNS = [
        "height_cm", "weight_kg", "bmi", "bp_systolic", "bp_diastolic", "temperature_c",
    ]

    def __init__(self, role: str = "viewer", username: str = ""):
        super().__init__("Vitals", VITALS_CSV, role, username)

    def on_add(self):
        dialog = VitalFormDialog(self, session_user=self._username)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        row = dialog.get_data()
        if not row.get("record_id"):
            row["record_id"] = new_id("VT")
        append_csv(VITALS_CSV, row, headers=self.DEFAULT_HEADERS)
        log_audit(self._username, "ADD", "Vitals", row["record_id"], row.get("patient_id", ""))
        self.load_data()

    def on_edit(self):
        row_data = self.selected_row_data()
        if not row_data:
            QMessageBox.warning(self, "Select Record", "Please select a vital record to edit.")
            return
        dialog = VitalFormDialog(self, row_data, session_user=self._username)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        updated_row = dialog.get_data()
        rid = row_data.get("record_id")
        updated = update_row(VITALS_CSV, lambda r: r.get("record_id") == rid,
                             updated_row, headers=self.DEFAULT_HEADERS)
        if not updated:
            QMessageBox.warning(self, "Update Failed", "Could not update the record.")
            return
        log_audit(self._username, "EDIT", "Vitals", rid, "")
        self.load_data()

    def on_delete(self):
        row_data = self.selected_row_data()
        if not row_data:
            QMessageBox.warning(self, "Select Record", "Please select a vital record to delete.")
            return
        answer = QMessageBox.question(
            self, "Delete Record",
            f"Delete vital record for patient {row_data.get('patient_id', '')}?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        rid = row_data.get("record_id")
        deleted = delete_rows(VITALS_CSV, lambda r: r.get("record_id") == rid,
                              headers=self.DEFAULT_HEADERS)
        if not deleted:
            QMessageBox.warning(self, "Delete Failed", "Could not delete the record.")
            return
        log_audit(self._username, "DELETE", "Vitals", rid, "")
        self.load_data()
