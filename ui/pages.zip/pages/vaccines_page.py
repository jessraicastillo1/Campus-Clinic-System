"""vaccines_page.py — Vaccinations CRUD with redesigned Royal Dark form."""

from __future__ import annotations

from PyQt6.QtCore    import Qt, QDate
from PyQt6.QtWidgets import (
    QComboBox, QDialog, QHBoxLayout, QLabel, QMessageBox, QWidget,
)

from backend.config   import VACCINES_CSV
from backend.utils    import new_id
from backend.database import append_csv, update_row, delete_rows
from ui.pages.table_page   import TablePage
from ui.pages._dialog_base import _BaseFormDialog

# =============================================================================

_STATUS_COLORS = {
    "Complete": "#1a7a4a",
    "Pending":  "#c9a227",
    "Missed":   "#c0392b",
}

class VaccineFormDialog(_BaseFormDialog):

    def __init__(self, parent=None, data: dict | None = None,
                 session_user: str = ""):
        super().__init__(parent, data, session_user)
        title = "Edit Vaccination" if data else "Add Vaccination"
        self._build_ui(title, bar_color="#1a3a8a")

    def _populate_form(self) -> None:
        d = self._data

        # ── AUTO ──
        self._section("Auto")
        self._f_record_id = self._ro_field(d.get("record_id", "") or "Auto-generated")
        self._row("Vaccination ID", self._f_record_id)
        self._f_patient = self._patient_combo(d.get("patient_id", ""))
        self._row("Patient ID", self._f_patient, required=True)
        self._spacer()

        # ── VACCINE ──
        self._section("Vaccine")
        self._f_vaccine = self._text_field("e.g. Hepatitis B, Flu Shot", d.get("vaccine_name", ""))
        self._row("Vaccine Name", self._f_vaccine, required=True)

        self._f_dose = self._spinbox(1, 99, int(d.get("dose", 1) or 1))
        self._row("Dose Number", self._f_dose)

        self._f_date_given = self._date_field(self._date_from_str(d.get("date_given", "")))
        self._row("Date Administered", self._f_date_given, required=True)

        self._f_next_due = self._date_field(self._date_from_str(d.get("next_due", "")))
        self._row("Next Due Date", self._f_next_due)

        self._f_admin_by = self._ro_field(d.get("administered_by", self._session_user))
        self._row("Administered By", self._f_admin_by)
        self._spacer()

        # ── STATUS ──
        self._section("Status")

        status_row = QWidget()
        status_lay = QHBoxLayout(status_row)
        status_lay.setContentsMargins(0, 0, 0, 0)
        status_lay.setSpacing(10)

        self._f_status = self._combo(list(_STATUS_COLORS.keys()), d.get("status", "Pending"))
        self._f_status.setMaximumWidth(160)
        status_lay.addWidget(self._f_status)

        self._status_pill = QLabel()
        self._status_pill.setFixedHeight(26)
        self._status_pill.setMinimumWidth(80)
        self._status_pill.setAlignment(Qt.AlignmentFlag.AlignCenter)
        status_lay.addWidget(self._status_pill)
        status_lay.addStretch()
        self._row("Status", status_row)

        self._f_status.currentTextChanged.connect(self._update_status_pill)
        self._update_status_pill(self._f_status.currentText())

        self._f_notes = self._textarea(2, "Optional notes…")
        self._f_notes.setPlainText(d.get("notes", ""))
        self._row("Notes", self._f_notes)

    def _update_status_pill(self, text: str) -> None:
        col = _STATUS_COLORS.get(text, "#1a3a8a")
        self._status_pill.setText(text)
        self._status_pill.setStyleSheet(
            f"background:{col}20; color:{col}; border:1px solid {col}60;"
            " border-radius:13px; padding:0 14px; font-size:11px; font-weight:700;"
        )

    def _on_save(self) -> None:
        if not self._patient_id_from_combo(self._f_patient):
            QMessageBox.warning(self, "Required", "Patient ID is required.")
            return
        if not self._f_vaccine.text().strip():
            QMessageBox.warning(self, "Required", "Vaccine Name is required.")
            return
        self._show_toast("Vaccination record saved successfully")
        from PyQt6.QtCore import QTimer
        QTimer.singleShot(400, self.accept)

    def get_data(self) -> dict:
        return {
            "record_id":       self._data.get("record_id", "") or new_id("VC"),
            "patient_id":      self._patient_id_from_combo(self._f_patient),
            "vaccine_name":    self._f_vaccine.text().strip(),
            "dose":            str(self._f_dose.value()),
            "date_given":      self._f_date_given.date().toString("yyyy-MM-dd"),
            "next_due":        self._f_next_due.date().toString("yyyy-MM-dd"),
            "administered_by": self._f_admin_by.text(),
            "status":          self._f_status.currentText(),
            "notes":           self._f_notes.toPlainText().strip(),
        }


# =============================================================================

class VaccinesPage(TablePage):
    DEFAULT_HEADERS = ["record_id", "patient_id", "vaccine_name", "dose", "date_given", "next_due"]

    def __init__(self, role: str = "viewer", username: str = ""):
        super().__init__("Vaccinations", VACCINES_CSV, role, username)

    def on_add(self):
        dialog = VaccineFormDialog(self, session_user=self._username)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        row = dialog.get_data()
        if not row.get("record_id"):
            row["record_id"] = new_id("VC")
        append_csv(VACCINES_CSV, row, headers=self.DEFAULT_HEADERS)
        self.load_data()

    def on_edit(self):
        row_data = self.selected_row_data()
        if not row_data:
            QMessageBox.warning(self, "Select Record", "Please select a vaccine record to edit.")
            return
        dialog = VaccineFormDialog(self, row_data, session_user=self._username)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        updated_row = dialog.get_data()
        rid = row_data.get("record_id")
        updated = update_row(VACCINES_CSV, lambda r: r.get("record_id") == rid,
                             updated_row, headers=self.DEFAULT_HEADERS)
        if not updated:
            QMessageBox.warning(self, "Update Failed", "Could not update.")
            return
        self.load_data()

    def on_delete(self):
        row_data = self.selected_row_data()
        if not row_data:
            QMessageBox.warning(self, "Select Record", "Please select a vaccine record to delete.")
            return
        answer = QMessageBox.question(
            self, "Delete Record",
            f"Delete {row_data.get('vaccine_name', '')} record for patient {row_data.get('patient_id', '')}?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        rid = row_data.get("record_id")
        deleted = delete_rows(VACCINES_CSV, lambda r: r.get("record_id") == rid,
                              headers=self.DEFAULT_HEADERS)
        if not deleted:
            QMessageBox.warning(self, "Delete Failed", "Could not delete.")
            return
        self.load_data()
