import os, sys, csv, datetime, hashlib
from datetime import datetime as _dt

from PyQt6.QtCore import Qt, QSize, QDate
from PyQt6.QtGui import QColor, QFont, QIcon, QLinearGradient, QBrush, QPainter, QPen
from PyQt6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QDateEdit, QDialog, QDialogButtonBox,
    QFormLayout, QFrame, QGraphicsDropShadowEffect, QGridLayout,
    QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem,
    QMainWindow, QMessageBox, QPushButton, QScrollArea,
    QStackedWidget, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from backend.config import *
from backend.utils import *
from backend.database import *
from backend.auth import *
from backend.inventory import *
from backend.queue_logic import *
from backend.models import Patient
from ui.pages.base_page import BasePage
from ui.pages.table_page import TablePage

# =============================================================================

class PatientFormDialog(QDialog):

    GENDER_OPTIONS     = ["Male", "Female", "Prefer not to say"]
    ROLE_TYPE_OPTIONS  = ["Student", "Faculty", "Staff", "Other"]
    BLOOD_TYPE_OPTIONS = ["", "A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-", "Unknown"]

    # ── Section definitions: (section_title, [headers]) ──────────────────────
    _SECTIONS = [
        ("Identity",       ["patient_id", "role_type"]),
        ("Personal Info",  ["first_name", "last_name", "dob", "gender"]),
        ("Medical",        ["blood_type", "allergies", "chronic_conditions"]),
        ("Contact",        ["email", "phone", "address"]),
    ]

    def __init__(self, parent=None, data=None):
        super().__init__(parent)
        self.setWindowTitle("Edit Patient" if data else "Add Patient")
        self._data   = data or {}
        self._fields = {}
        self._init_ui()

    # ── Internal helper: build one field widget ────────────────────────────
    def _make_field(self, header):
        if header == "patient_id":
            field = QLineEdit()
            field.setText(self._data.get(header, ""))
            field.setPlaceholderText("Auto-generated if left blank")
            if self._data:
                field.setReadOnly(True)

        elif header == "role_type":
            field = QComboBox()
            field.addItems(self.ROLE_TYPE_OPTIONS)
            current = self._data.get(header, "")
            if current in self.ROLE_TYPE_OPTIONS:
                field.setCurrentText(current)
            elif current:
                field.addItem(current); field.setCurrentText(current)

        elif header == "dob":
            field = QDateEdit()
            field.setCalendarPopup(True)
            field.setDisplayFormat("MM/dd/yyyy")
            raw = self._data.get(header, "")
            if raw:
                try:
                    parts = raw.split("-")
                    if len(parts) == 3:
                        field.setDate(QDate(int(parts[0]), int(parts[1]), int(parts[2])))
                    else:
                        field.setDate(QDate.currentDate())
                except (ValueError, IndexError):
                    field.setDate(QDate.currentDate())
            else:
                field.setDate(QDate(2000, 1, 1))

        elif header == "gender":
            field = QComboBox()
            field.addItems(self.GENDER_OPTIONS)
            current = self._data.get(header, "")
            if current in self.GENDER_OPTIONS:
                field.setCurrentText(current)
            elif current:
                field.addItem(current); field.setCurrentText(current)

        elif header == "blood_type":
            field = QComboBox()
            field.addItems(self.BLOOD_TYPE_OPTIONS)
            current = self._data.get(header, "")
            if current in self.BLOOD_TYPE_OPTIONS:
                field.setCurrentText(current)
            elif current:
                field.addItem(current); field.setCurrentText(current)

        else:
            field = QLineEdit()
            field.setText(self._data.get(header, ""))
            if header == "allergies":
                field.setPlaceholderText("e.g. Penicillin, Sulfa drugs  (or 'None')")
            elif header == "chronic_conditions":
                field.setPlaceholderText("e.g. Asthma, Hypertension  (or 'None')")
            elif header == "email":
                field.setPlaceholderText("e.g. juan@email.com")
            elif header == "phone":
                field.setPlaceholderText("e.g. 09XX-XXX-XXXX")
            elif header == "address":
                field.setPlaceholderText("Street, Barangay, City")

        return field

    def _init_ui(self):
        # ── Outer layout ──────────────────────────────────────────────────
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # ── Title bar ─────────────────────────────────────────────────────
        title_bar = QWidget()
        title_bar.setObjectName("modal_titlebar")
        title_bar.setFixedHeight(46)
        tb_layout = QHBoxLayout(title_bar)
        tb_layout.setContentsMargins(18, 0, 18, 0)
        title_lbl = QLabel("Edit Patient" if self._data else "Add Patient")
        title_lbl.setObjectName("modal_title")
        tb_layout.addWidget(title_lbl)
        outer.addWidget(title_bar)

        # ── Scroll area wrapping all form sections ─────────────────────────
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)

        body = QWidget()
        body_layout = QVBoxLayout(body)
        body_layout.setContentsMargins(20, 16, 20, 8)
        body_layout.setSpacing(16)

        # ── Build each section ────────────────────────────────────────────
        for section_title, headers in self._SECTIONS:
            # Section header label
            sec_lbl = QLabel(section_title.upper())
            sec_lbl.setStyleSheet(
                "color: #1a3a8a; font-size: 10px; font-weight: 800; "
                "letter-spacing: 1.1px; padding-bottom: 2px; "
                "border-bottom: 2px solid #d0d8ef; margin-bottom: 2px;"
            )
            body_layout.addWidget(sec_lbl)

            # Form layout for this section
            form = QFormLayout()
            form.setLabelAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            form.setFormAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
            form.setHorizontalSpacing(14)
            form.setVerticalSpacing(10)
            form.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.ExpandingFieldsGrow)

            for header in headers:
                label_text = header.replace("_", " ").title() + ":"
                field = self._make_field(header)
                self._fields[header] = field

                lbl = QLabel(label_text)
                lbl.setMinimumWidth(130)
                lbl.setStyleSheet("font-weight: 600; color: #5a6480; font-size: 12px;")
                form.addRow(lbl, field)

            body_layout.addLayout(form)

        body_layout.addStretch()
        scroll.setWidget(body)
        outer.addWidget(scroll, 1)

        # ── Divider ───────────────────────────────────────────────────────
        divider = QFrame()
        divider.setFrameShape(QFrame.Shape.HLine)
        divider.setStyleSheet("color: #d0d8ef;")
        outer.addWidget(divider)

        # ── Button row ────────────────────────────────────────────────────
        btn_row = QWidget()
        btn_row.setStyleSheet("background: #ffffff;")
        btn_layout = QHBoxLayout(btn_row)
        btn_layout.setContentsMargins(20, 12, 20, 14)
        btn_layout.setSpacing(10)
        btn_layout.addStretch()

        cancel_btn = QPushButton("Cancel")
        cancel_btn.setFixedHeight(36)
        cancel_btn.setMinimumWidth(90)
        cancel_btn.clicked.connect(self.reject)

        save_btn = QPushButton("Save")
        save_btn.setObjectName("btn_primary")
        save_btn.setFixedHeight(36)
        save_btn.setMinimumWidth(90)
        save_btn.clicked.connect(self._on_accept)

        btn_layout.addWidget(cancel_btn)
        btn_layout.addWidget(save_btn)
        outer.addWidget(btn_row)

        # ── Dialog sizing ─────────────────────────────────────────────────
        self.setMinimumWidth(520)
        self.setMinimumHeight(540)
        self.resize(540, 620)

    def _on_accept(self):
        """Validate before accepting."""
        data = self.get_data()
        patient = Patient(data)
        errors  = patient.validate()
        if errors:
            QMessageBox.warning(self, "Validation Error", "\n".join(errors))
            return
        self.accept()

    def get_data(self):
        result = {}
        for h in PatientPage.DEFAULT_HEADERS:
            widget = self._fields[h]
            if isinstance(widget, QComboBox):
                result[h] = widget.currentText().strip()
            elif isinstance(widget, QDateEdit):
                result[h] = widget.date().toString("yyyy-MM-dd")
            else:
                result[h] = widget.text().strip()
        return result


class PatientPage(TablePage):
    DEFAULT_HEADERS = [
        "patient_id", "role_type", "first_name", "last_name", "dob", "gender",
        "blood_type", "allergies", "chronic_conditions", "email", "phone", "address",
    ]
    # PHI fields hidden from viewer accounts
    SENSITIVE_COLUMNS = [
        "dob", "blood_type", "allergies", "chronic_conditions", "email", "phone", "address",
    ]

    def __init__(self, role: str = "viewer", username: str = ""):
        super().__init__("Patients", PATIENTS_CSV, role, username)

    def on_add(self):
        dialog = PatientFormDialog(self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        row = dialog.get_data()
        if not row.get("patient_id"):
            row["patient_id"] = new_id("P")
        append_csv(PATIENTS_CSV, row, headers=self.DEFAULT_HEADERS)
        log_audit(self._username, "ADD", "Patients", row["patient_id"], row.get("first_name","") + " " + row.get("last_name",""))
        self.load_data()

    def on_edit(self):
        row_data = self.selected_row_data()
        if not row_data:
            QMessageBox.warning(self, "Select Patient", "Please select a patient to edit.")
            return
        dialog = PatientFormDialog(self, row_data)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        updated_row = dialog.get_data()
        pid = row_data.get("patient_id")
        updated = update_row(PATIENTS_CSV, lambda row: row.get("patient_id") == pid,
                             updated_row, headers=self.DEFAULT_HEADERS)
        if not updated:
            QMessageBox.warning(self, "Update Failed", "The selected patient could not be updated.")
            return
        log_audit(self._username, "EDIT", "Patients", pid, "")
        self.load_data()

    def on_delete(self):
        row_data = self.selected_row_data()
        if not row_data:
            QMessageBox.warning(self, "Select Patient", "Please select a patient to delete.")
            return
        answer = QMessageBox.question(
            self, "Delete Patient",
            f"Delete patient {row_data.get('first_name', '')} {row_data.get('last_name', '')}?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        pid = row_data.get("patient_id")
        deleted = delete_rows(PATIENTS_CSV, lambda row: row.get("patient_id") == pid,
                              headers=self.DEFAULT_HEADERS)
        if not deleted:
            QMessageBox.warning(self, "Delete Failed", "The selected patient could not be deleted.")
            return
        log_audit(self._username, "DELETE", "Patients", pid, "")
        self.load_data()


# ── Helper: get patient allergies by ID ──────────────────────────────────────

def get_patient_allergies(patient_id: str) -> str:
    for row in read_csv(PATIENTS_CSV):
        if row.get("patient_id") == patient_id:
            return row.get("allergies", "")
    return ""


# =============================================================================
