"""prescriptions_page.py — Prescriptions CRUD with redesigned Royal Dark form."""

from __future__ import annotations

from PyQt6.QtCore    import QTimer
from PyQt6.QtWidgets import QDialog, QMessageBox

from backend.config    import PRESCRIPTIONS_CSV
from backend.utils     import new_id
from backend.database  import append_csv, update_row, delete_rows
from ui.pages.table_page   import TablePage
from ui.pages._dialog_base import _BaseFormDialog

# =============================================================================

class PrescriptionFormDialog(_BaseFormDialog):

    def __init__(self, parent=None, data=None, session_user=""):
        super().__init__(parent, data, session_user)
        self._build_ui("Edit Prescription" if data else "Add Prescription", bar_color="#1a3a8a")

    def _populate_form(self):
        d = self._data

        self._section("Auto")
        self._f_rx_id = self._ro_field(d.get("rx_id", "") or "Auto-generated")
        self._row("Prescription ID", self._f_rx_id)
        self._f_patient = self._patient_combo(d.get("patient_id", ""))
        self._row("Patient ID", self._f_patient, required=True)
        self._spacer()

        self._section("Prescription")
        self._f_date = self._date_field(self._date_from_str(d.get("date", "")))
        self._row("Date Issued", self._f_date, required=True)

        self._f_drug = self._text_field("e.g. Biogesic 500mg", d.get("drug_name", ""))
        self._row("Medicine Name", self._f_drug, required=True)

        self._f_dosage = self._text_field("e.g. 1 tablet every 8 hours", d.get("dosage", ""))
        self._row("Dosage", self._f_dosage, required=True)

        self._f_frequency = self._combo([
            "", "Once daily", "Twice daily", "Three times daily", "Four times daily",
            "Every 4 hours", "Every 6 hours", "Every 8 hours", "Every 12 hours",
            "As needed", "Weekly", "Bi-weekly", "Monthly",
        ], d.get("frequency", ""))
        self._row("Frequency", self._f_frequency)

        self._f_duration = self._text_field("e.g. 5 days", d.get("duration_days", ""))
        self._row("Duration", self._f_duration)

        try:
            qty_val = int(d.get("quantity", 1) or 1)
        except Exception:
            qty_val = 1
        self._f_qty = self._spinbox(1, 9999, qty_val)
        self._row("Quantity", self._f_qty)
        self._spacer()

        self._section("Notes")
        self._f_instructions = self._textarea(3, "e.g. Take after meals")
        self._f_instructions.setPlainText(d.get("instructions", ""))
        self._row("Instructions", self._f_instructions)

        self._f_prescribed_by = self._ro_field(
            d.get("prescribed_by", self._session_user) or self._session_user)
        self._row("Prescribed By", self._f_prescribed_by)

    def _on_save(self):
        if not self._patient_id_from_combo(self._f_patient):
            QMessageBox.warning(self, "Required", "Patient ID is required.")
            return
        if not self._f_drug.text().strip():
            QMessageBox.warning(self, "Required", "Medicine Name is required.")
            return
        if not self._f_dosage.text().strip():
            QMessageBox.warning(self, "Required", "Dosage is required.")
            return
        rxid = self._data.get("rx_id", "") or new_id("RX")
        self._saved_id = rxid
        self._show_toast(f"Prescription {rxid} issued successfully")
        QTimer.singleShot(400, self.accept)

    def get_data(self):
        return {
            "rx_id":        self._data.get("rx_id", "") or getattr(self, "_saved_id", new_id("RX")),
            "patient_id":   self._patient_id_from_combo(self._f_patient),
            "date":         self._f_date.date().toString("yyyy-MM-dd"),
            "drug_name":    self._f_drug.text().strip(),
            "dosage":       self._f_dosage.text().strip(),
            "frequency":    self._f_frequency.currentText(),
            "duration_days":self._f_duration.text().strip(),
            "quantity":     str(self._f_qty.value()),
            "instructions": self._f_instructions.toPlainText().strip(),
            "prescribed_by":self._f_prescribed_by.text().strip(),
        }


# =============================================================================

class PrescriptionsPage(TablePage):
    DEFAULT_HEADERS = [
        "rx_id", "patient_id", "date", "drug_name", "dosage",
        "frequency", "duration_days", "quantity", "instructions", "prescribed_by",
    ]
    SENSITIVE_COLUMNS = ["drug_name", "dosage", "frequency", "duration_days", "instructions"]

    def __init__(self, role="viewer", username=""):
        super().__init__("Prescriptions", PRESCRIPTIONS_CSV, role, username)

    def on_add(self):
        dialog = PrescriptionFormDialog(self, session_user=self._username)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        row = dialog.get_data()
        if not row.get("rx_id"):
            row["rx_id"] = new_id("RX")
        append_csv(PRESCRIPTIONS_CSV, row, headers=self.DEFAULT_HEADERS)
        self.load_data()

    def on_edit(self):
        row_data = self.selected_row_data()
        if not row_data:
            QMessageBox.warning(self, "Select Prescription", "Please select a prescription to edit.")
            return
        dialog = PrescriptionFormDialog(self, row_data, session_user=self._username)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        updated_row = dialog.get_data()
        updated = update_row(PRESCRIPTIONS_CSV,
                             lambda r: r.get("rx_id") == row_data.get("rx_id"),
                             updated_row, headers=self.DEFAULT_HEADERS)
        if not updated:
            QMessageBox.warning(self, "Update Failed", "The selected prescription could not be updated.")
            return
        self.load_data()

    def on_delete(self):
        row_data = self.selected_row_data()
        if not row_data:
            QMessageBox.warning(self, "Select Prescription", "Please select a prescription to delete.")
            return
        answer = QMessageBox.question(self, "Delete Prescription",
            f"Delete {row_data.get('drug_name', '')} for patient {row_data.get('patient_id', '')}?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if answer != QMessageBox.StandardButton.Yes:
            return
        deleted = delete_rows(PRESCRIPTIONS_CSV,
                              lambda r: r.get("rx_id") == row_data.get("rx_id"),
                              headers=self.DEFAULT_HEADERS)
        if not deleted:
            QMessageBox.warning(self, "Delete Failed", "The selected prescription could not be deleted.")
            return
        self.load_data()
